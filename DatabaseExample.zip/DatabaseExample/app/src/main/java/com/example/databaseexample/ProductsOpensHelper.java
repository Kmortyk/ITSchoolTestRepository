package com.example.databaseexample;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

class ProductsDatabase {
    public final static String DATABASE_NAME = "products";
    public final static int VERSION = 1;
    public static final String TABLE_PRODUCTS = "products";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_PRICE = "price";
}

public class ProductsOpensHelper extends SQLiteOpenHelper {
    public ProductsOpensHelper(Context context) {
        super(context, ProductsDatabase.DATABASE_NAME,
                null, ProductsDatabase.VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " +
                ProductsDatabase.TABLE_PRODUCTS + " (" +
                ProductsDatabase.COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                ProductsDatabase.COLUMN_NAME + " TEXT NOT NULL," +
                ProductsDatabase.COLUMN_PRICE + " INTEGER NOT NULL);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int ver1, int ver2) {
        db.execSQL("DROP TABLE " + ProductsDatabase.DATABASE_NAME + ";");
    }
}
