package com.example.databaseexample;

import android.app.ListActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;

import androidx.annotation.Nullable;

public class ProductsListActivity extends ListActivity {

    private ProductsRepository repository;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        repository = new ProductsRepository(this);

        ArrayAdapter<String> adapter =
                new ArrayAdapter<String>(
                        this, android.R.layout.simple_list_item_1
                );

        for(ProductsRepository.Product p : repository.selectAll()) {
            adapter.add(p.name + " " + p.price);
        }

        setListAdapter(adapter);
    }
}
