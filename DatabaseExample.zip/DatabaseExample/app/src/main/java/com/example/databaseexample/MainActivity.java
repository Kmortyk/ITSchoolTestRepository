package com.example.databaseexample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private ProductsRepository repository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        repository = new ProductsRepository(this);

        EditText etName = findViewById(R.id.et_name);
        EditText etPrice = findViewById(R.id.et_price);
        Button btnInsert = findViewById(R.id.btn_insert);
        Button btnNext = findViewById(R.id.btn_next);

        btnInsert.setOnClickListener(v -> {
            String name = etName.getText().toString();
            int price = Integer.parseInt(etPrice.getText().toString());

            repository.insert(name, price);
        });

        btnNext.setOnClickListener(v -> {
            Intent i = new Intent(MainActivity.this,
                    ProductsListActivity.class);
            startActivity(i);
        });
    }
}