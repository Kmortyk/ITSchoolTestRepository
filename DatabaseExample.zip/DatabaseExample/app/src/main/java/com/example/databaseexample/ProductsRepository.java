package com.example.databaseexample;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class ProductsRepository {

    private SQLiteDatabase db;

    public ProductsRepository(Context context) {
        ProductsOpensHelper products =
                new ProductsOpensHelper(context);

        db = products.getWritableDatabase();
    }

    public void insert(String name, int price) {
        ContentValues cv = new ContentValues();
        cv.put(ProductsDatabase.COLUMN_NAME, name);
        cv.put(ProductsDatabase.COLUMN_PRICE, price);

        db.insert(
                ProductsDatabase.TABLE_PRODUCTS,
                null, cv
        );
    }

    class Product {
        String name;
        int price;
    }

    public List<Product> selectAll() {
        Cursor cursor = db.query(
                ProductsDatabase.TABLE_PRODUCTS,
                null, null,
                null, null,
                null, null
        );

        List<Product> list = new ArrayList<>();

        cursor.moveToFirst();

        do {
            Product product = new Product();

            product.name = cursor.getString(1);
            product.price = cursor.getInt(2);

            list.add(product);
        } while(cursor.moveToNext());

        return list;
    }
}
